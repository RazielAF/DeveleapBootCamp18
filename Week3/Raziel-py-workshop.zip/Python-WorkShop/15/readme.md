This time no story, no theory. 
The examples below show you how to write function:

### Examples:
```py 
main("abcd") -> "A-Bb-Ccc-Dddd"
main("RqaEzty") -> "R-Qq-Aaa-Eeee-Zzzzz-Tttttt-Yyyyyyy"
main("cwt.") -> "C-Ww-Ttt-...."
```