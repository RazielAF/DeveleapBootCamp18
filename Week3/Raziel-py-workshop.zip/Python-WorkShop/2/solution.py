def main(str):
  return str[::-1]


